#!/usr/bin/env python3
"""
Pre-Flight Validator for Coder Delivery Transactions (Transfer Protocol 2)
Usage:
    python verify_handoff_transaction.py <path_to_CODER_DELIVERY_TRANSACTION.json>
"""

import os
import sys
import json
import hashlib

CANONICAL_OPERATIONS = {
    "RETRIEVE", "EXPLAIN", "APPLY", "MODEL", "REPRESENT", "SYNTHESIZE", "JUSTIFY"
}

FORBIDDEN_VERBS = {
    "IDENTIFY", "CALCULATE", "SOLVE", "GUESS", "FIND", "CONNECT", "TRANSFORM", "EXECUTE"
}

def verify_transaction(tx_path):
    print(f"[Pre-Flight Verification] Checking transaction: {tx_path}")
    if not os.path.isfile(tx_path):
        print(f"FAIL: Transaction file does not exist: {tx_path}")
        return 1

    try:
        with open(tx_path, "r", encoding="utf-8") as f:
            tx = json.load(f)
    except Exception as e:
        print(f"FAIL: Invalid JSON in transaction file: {e}")
        return 1

    # 1. Contract & Governance assertions
    if tx.get("contract") != "grade9v4-coder-delivery-tx-v1":
        print(f"FAIL: Invalid contract: {tx.get('contract')}")
        return 1

    if tx.get("governance_status") != "HOLD:ACADEMIC_ADMISSION":
        print(f"FAIL: Governance status must be HOLD:ACADEMIC_ADMISSION, got: {tx.get('governance_status')}")
        return 1

    # 2. Attestation check
    att = tx.get("self_check_attestation", {})
    if att.get("unit_test_exit_code") != 0:
        print(f"FAIL: Builder unit tests did not pass (code {att.get('unit_test_exit_code')})")
        return 1

    if att.get("playwright_exit_code") != 0:
        print(f"FAIL: Builder Playwright audit did not pass (code {att.get('playwright_exit_code')})")
        return 1

    if not att.get("zero_overflow_mobile_375") or not att.get("zero_overflow_desktop_1365"):
        print(f"FAIL: Builder attested horizontal scroll overflow detected")
        return 1

    # 3. Archive file verification
    archive_path = tx.get("archive_path")
    if archive_path:
        base_dir = os.path.dirname(os.path.abspath(tx_path))
        full_archive_path = os.path.normpath(os.path.join(base_dir, archive_path))
        if not os.path.isfile(full_archive_path):
            # Check relative to workspace
            full_archive_path = os.path.abspath(archive_path)
            if not os.path.isfile(full_archive_path):
                print(f"FAIL: Sealed candidate archive missing: {archive_path}")
                return 1

        with open(full_archive_path, "rb") as af:
            actual_bytes = len(af.read())
            af.seek(0)
            actual_sha = hashlib.sha256(af.read()).hexdigest()

        if actual_bytes != tx.get("archive_bytes"):
            print(f"FAIL: Archive byte size mismatch: expected {tx.get('archive_bytes')}, got {actual_bytes}")
            return 1

        if actual_sha != tx.get("archive_sha256"):
            print(f"FAIL: Archive SHA-256 mismatch: expected {tx.get('archive_sha256')}, got {actual_sha}")
            return 1

        print(f"  [Archive Verified] {os.path.basename(full_archive_path)} ({actual_bytes} bytes, SHA: {actual_sha[:16]}...)")

    print(">>> TRANSACTION PRE-FLIGHT VERIFICATION PASSED (READY FOR AUDITOR) <<<")
    return 0

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python verify_handoff_transaction.py <path_to_CODER_DELIVERY_TRANSACTION.json>")
        sys.exit(1)
    sys.exit(verify_transaction(sys.argv[1]))
