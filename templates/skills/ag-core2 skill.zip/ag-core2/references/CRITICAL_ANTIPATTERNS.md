# Detailed Reference: The 7 Critical Anti-Patterns & Code Fixes

This document details the exact code patterns, regression risks, and drop-in fixes for the 7 anti-patterns in Core 2 engineering.

---

### 1. Lexical Ghost Text ("2. Connection:")

* **The Defect:**
  Legacy generators output:
  ```json
  "reasoning": [
    "1. System Representation & Setup: ...",
    "2. Connection: By applying Work-Energy Theorem ...",
    "3. Execution & Resolution: ..."
  ]
  ```
* **The Fix:**
  Replace with the canonical scientific modeling header:
  ```json
  "reasoning": [
    "1. System Representation & Setup: Declare system boundary [block + incline + Earth] and datum U = 0.",
    "2. Physical Model & Formulation: Formulate Work-Energy balance W_g + W_f = Delta K.",
    "3. Execution & Resolution: Solve algebraically for mu = 3*tan(theta)."
  ]
  ```

---

### 2. Static Crux Move Hardcoding

* **The Defect:**
  Statically writing `"crux_move_ref": "WPE-B5-QXX-M2"` for every item.
* **The Fix:**
  Dynamically bind the crux reference and the protected scaffold:
  ```python
  if op in ("RETRIEVE", "REPRESENT"):
      crux_ref = f"WPE-BX-Q{seq:02d}-M1"
      scaf_crux_tier = 1
  elif op == "JUSTIFY":
      crux_ref = f"WPE-BX-Q{seq:02d}-M3"
      scaf_crux_tier = 3
  else: # MODEL, SYNTHESIZE, APPLY
      crux_ref = f"WPE-BX-Q{seq:02d}-M2"
      scaf_crux_tier = 2
  ```

---

### 3. Complexity Rubric Sum Drift

* **The Defect:**
  Setting `score: 7` while components sum to `5`, or scoring an individual component $> 2$.
* **The Fix:**
  Strictly score all 5 dimensions in $\{0, 1, 2\}$ and compute total score as the sum:
  ```python
  comp_scores = {
      "concept_model_selection": 1,
      "representation_translation": 2,
      "reasoning_chain_length": 2,
      "algebra_computational_load": 1,
      "trap_exception_sensitivity": 1
  }
  total_score = sum(comp_scores.values()) # Exactly 7 -> Band D3
  assert all(0 <= v <= 2 for v in comp_scores.values())
  assert sum(comp_scores.values()) == total_score
  ```

---

### 4. Non-Canonical Verbs

* **The Defect:**
  Using `"kind": "CALCULATE"`, `"kind": "SOLVE"`, `"kind": "IDENTIFY"`, or `"kind": "CONNECT"`.
* **The Fix:**
  Filter against canonical 7 verbs only:
  ```python
  CANONICAL_OPERATIONS = {
      "RETRIEVE", "EXPLAIN", "APPLY", "MODEL", "REPRESENT", "SYNTHESIZE", "JUSTIFY"
  }
  assert move_kind in CANONICAL_OPERATIONS
  assert primary_op in CANONICAL_OPERATIONS
  ```

---

### 5. Invalid SVG Root Dimensions

* **The Defect:**
  `<svg viewBox="0 0 540 280" width="100%" height="auto">`
  Chromium throws: `Invalid attribute value: height="auto"`.
* **The Fix:**
  ```xml
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 540 280" width="100%" height="100%">
  ```
  And in CSS:
  ```css
  .q-fig-box img, .q-fig-box svg {
    max-width: 100%;
    height: auto;
    display: block;
    margin: 0 auto;
  }
  ```

---

### 6. Mobile Viewport CSS Cascade Order

* **The Defect:**
  Declaring `.drawer-card { position: sticky; }` *after* the `@media (max-width: 900px)` block.
* **The Fix:**
  Place desktop styles first, followed by mobile media queries:
  ```css
  /* Desktop styles */
  .drawer-nav { position: sticky; top: 80px; }
  .num-input { max-width: 220px; }

  /* Mobile overrides */
  @media (max-width: 600px) {
    .drawer-nav { position: static; }
    .num-input { max-width: 100%; }
    .commit-btn { width: 100%; }
  }
  ```

---

### 7. Formative Derivation Leaks

* **The Defect:**
  Derivation sections visible before learner attempt.
* **The Fix:**
  Hardcode `display: none;` on `.derivation-section` and require an event to commit:
  ```css
  .derivation-section { display: none; }
  .derivation-section.revealed { display: block; animation: fadeIn 0.3s ease; }
  ```
  ```javascript
  function commitAnswer(seq) {
    state.committed[seq] = true;
    document.getElementById('commit-btn-q' + seqStr).disabled = true;
    const deriv = document.getElementById('derivation-q' + seqStr);
    if (deriv) {
      deriv.classList.add('revealed');
      deriv.style.display = 'block';
    }
  }
  ```

---

### 8. Adversarial Developer Mock Strings & Jargon Leaks

* **The Defect:**
  Displaying developer/mock phrases in student UI:
  `SELECTED · DIFFERS FROM PRODUCER PROPOSAL`, `PRODUCER-PROPOSED · NOT SELECTED`, `Comparison with producer-proposed key · REVIEWED`, `asserted stem digest agrees with display · QRT HOLD`.
* **The Fix:**
  Strictly separate pedagogical presentation from internal audit records. Render student-facing attempt feedback banners (`✅ CORRECT` / `❌ INCORRECT`), option badges (`opt-user-correct`, `opt-user-wrong`, `opt-correct-key`), and encapsulate all raw hashes and QRT formulas inside a collapsed `<details>` drawer:
  ```html
  <details class="q-source-custody-drawer">
    <summary>Data integrity &amp; QRT verification (technical audit; not admission)</summary>
    <div class="custody-hash-dump">
      <code>Stem SHA-256: 4a2f8...</code>
    </div>
  </details>
  ```

---

### 9. SVG Named Entity XML Parser Crashes

* **The Defect:**
  Using HTML named entities inside SVG vector diagrams: `&middot;`, `&rarr;`, `&cross;`, `&Delta;`.
  Chromium's XML parser crashes with: `error on line X at column Y: Entity 'middot' not defined`, rendering a blank square on tablets.
* **The Fix:**
  Use only literal UTF-8 characters (`·`, `→`, `✕`, `Δ`) or XML numeric character entities (`&#183;`, `&#8594;`):
  ```xml
  <!-- WRONG: Crashes XML parser -->
  <text x="20" y="30">u &middot; v</text>
  <!-- CORRECT: 100% XML Strict -->
  <text x="20" y="30">u · v</text>
  ```

---

### 10. Missing Post-Commitment Feedback & Reset State Machine

* **The Defect:**
  Freezing option buttons upon commitment without rendering an explicit result banner or providing any way for the student to reset their attempt and try again.
* **The Fix:**
  Implement the full 3-state evaluation lifecycle with an interactive `[🔄 Reset & Try Again]` control:
  ```javascript
  function resetAttempt(seq) {
    delete state.committed[seq];
    delete state.selected[seq];
    // Re-enable option buttons and inputs
    options.forEach(opt => { opt.disabled = false; opt.classList.remove('opt-user-correct', 'opt-user-wrong', 'opt-correct-key'); });
    // Hide derivation and feedback banner
    deriv.style.display = 'none';
    feedbackBanner.remove();
  }
  ```

---

### 11. Stale Browser Script Cache Serving

* **The Defect:**
  Serving `.js` and `.json` reader files without cache invalidation headers on local Python/preview servers. Tablet browsers cache files on disk, executing stale logic even after code fixes.
* **The Fix:**
  1. Append cache-busting version query strings (`?v=4.1.x`) to all `<script>` tags in HTML.
  2. Pass `{ cache: "no-store" }` to every client-side `fetch()` call for JSON candidate data.

---

### 12. Dead Anchor Links & Unhandled Workspace Navigation

* **The Defect:**
  Using placeholder dummy anchors like `<a class="primary-topic-btn" href="#topic-view">` pointing to an element inside `#topicWorkspace`, which has `display: none;` by default. The browser scrolls nowhere, nothing unhides, and the user experiences a completely broken button.
* **The Fix:**
  1. Primary topic action buttons must explicitly invoke active topic selection:
     ```html
     <button type="button" class="primary-topic-btn" onclick="window.selectBiologyTopic('genetics')">
       ▶ Open Genetics &amp; Heredity Questions (23 Qs) →
     </button>
     ```
  2. Frontend readers must handle `#topic-view` or `#topicWorkspace` on page load and hash change by unhiding `#topicWorkspace`, activating the default topic pill, and smoothly scrolling into view:
     ```javascript
     if (initialHash === "topic-view" || initialHash === "topicWorkspace") {
       filterState.topic = defaultTopicSlug;
       applyFilters(true);
     }
     ```

---

### 13. Escaped Quote HTML Attribute Syntax Traps

* **The Defect:**
  Writing backslash-escaped single quotes inside double-quoted HTML attributes:
  `<a onclick="window.selectBiologyTopic(\'living_world\')">`.
  HTML attribute parsers do NOT recognize backslash as an escape character; the attribute value is parsed as `"window.selectBiologyTopic(\"`, causing immediate string truncation and a fatal JavaScript syntax error upon clicking.
* **The Fix:**
  Always use clean, unescaped single quotes inside double quotes:
  ```html
  <a onclick="window.selectBiologyTopic('living_world')">
  ```

---

### 14. Unrendered Figure Assets in Frontend Reader DOM

* **The Defect:**
  The candidate JSON declares `source_figures: ["fig_bio_water_potential.svg"]`, but the subject frontend reader (`core2-biology-reader.js`) completely omits the figure rendering code block, resulting in missing diagrams on student cards.
* **The Fix:**
  Every reader must inspect `q.source_figures` immediately beneath the question stem and construct a responsive figure container with `candidate-fig-img` and `onerror` fallback:
  ```javascript
  if (Array.isArray(q.source_figures) && q.source_figures.length > 0) {
    const figWrap = text("div", "", "figure-container");
    q.source_figures.forEach(fig => {
      const img = document.createElement("img");
      img.src = "../assets/" + fig;
      img.alt = q.figure_note || fig;
      img.onerror = () => { img.src = "assets/" + fig; };
      figWrap.appendChild(img);
    });
    box.appendChild(figWrap);
  }
  ```

---

### 15. Single-Directory SVG Asset Isolation & 404 Discrepancies

* **The Defect:**
  Authoring an SVG into `nsejs/assets/` without placing a copy in `nsejs/<subject>/assets/` (or vice-versa). Pages operating at different URL directory depths (`/nsejs/index.html` vs `/nsejs/biology/question-bank.html`) fail to load images when relative paths mismatch.
* **The Fix:**
  Enforce synchronous dual-placement: whenever an SVG is generated or updated, write it simultaneously to both `nsejs/assets/` and `nsejs/<subject>/assets/`.

---

### 16. Stale Search Index Manifest Disconnect

* **The Defect:**
  Modifying question banks, metadata, or topic mappings without rebuilding the global search index. The portal-wide command palette returns stale question IDs or missing topics, and the manifest SHA-256 pin diverges from disk content.
* **The Fix:**
  Run `python tools/build_search_index.py` after any bank modifications, assert that `learner-search-index.v1.json` is regenerated, and seal its SHA-256 digest into `learner-search-manifest.v1.json`.

