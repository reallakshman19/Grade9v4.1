# Canonical Transfer Protocols Specification
**Grade9 v4.0 · Oracle ↔ Builder ↔ Reviewer ↔ B2 Bounded Transfer Triangle**

This specification defines the four mandatory transfer protocols governing work dispatch, delivery handoff, repair return, and escalation receipts across Grade9 Core 2 engineering. It operationalizes `G9V4_ORACLE_LOCAL_AGENT_PROTOCOL_v0.2.html` and enforces fail-closed state transitions.

---

## 1. The Transfer Triangle & State Machine

```mermaid
stateDiagram-v2
    direction TB
    [*] --> DISPATCHED: Protocol 1 (WORK_ORDER.json)
    DISPATCHED --> BUILDER_TESTED: Coder Builds & Self-Checks
    BUILDER_TESTED --> LOCAL_REVIEW_QUEUE: Protocol 2 (CODER_DELIVERY_TRANSACTION.json)
    
    LOCAL_REVIEW_QUEUE --> LOCAL_REVIEWED: Reviewer Audits (Dual Gate)
    
    LOCAL_REVIEWED --> REPAIR_MODE: Audit FAILS (Protocol 3: LOCAL_EXECUTION_RETURNED.json)
    REPAIR_MODE --> BUILDER_TESTED: Coder Remediates Defects
    
    LOCAL_REVIEWED --> B2_QUALIFIED: Audit PASSES (Protocol 4: BATCH_ARCHIVE_RECEIPT.json)
    LOCAL_REVIEWED --> GAP_ESCALATION: Protocol 4 (GAP_NOTE.json)
    
    B2_QUALIFIED --> [*]: Ready for Human Academic Review
```

---

## 2. Transfer Protocol 1: Oracle → Builder (Work Order Dispatch)

* **Direction:** Oracle / Orchestrator $\to$ Builder / Coder Agent.
* **Payload File:** `WORK_ORDER.json` (Read-only, matching `G9V4_LOCAL_AGENT_WORK_ORDER_SCHEMA_v0.1.json`).
* **Enforced Invariants:**
  1. The builder agent must halt immediately with `HOLD:BASELINE_DRIFT` if git HEAD or branch pins do not match.
  2. Bounded writes: The coder may *only* write to `allowed_write_root` (e.g. `workspace/output/G9V4_LOTS/<ORDER>/`).
  3. No scope widening: Prose instructions cannot silently widen `candidate_ids`.

### Schema Format (`WORK_ORDER.json`)
```json
{
  "contract": "G9V4-OLA-THREE-LOOP/0.2-candidate",
  "order_id": "LOT-14-CORE2-B05-001",
  "workflow": "WPE_OWNER_SCOPED_CORE2_FIRST",
  "operation_mode": "QUALIFICATION_PREP",
  "repo_root": "D:/CodeD/grade9v4",
  "expected_branch": "feat/core2-template-corrections-and-local-source-receipt",
  "expected_head_sha": "18c861cea17b5d50d492ef85e6ec3ad73e659832",
  "candidate_ids": ["Q61", "Q62", "Q63", "Q64", "Q65", "Q66", "Q67", "Q68", "Q69", "Q70"],
  "max_active_candidates": 10,
  "allowed_read_roots": ["workspace/", "docs/agent-entry/", "AGENTS.md", "Start_here.md"],
  "allowed_write_root": "workspace/output/G9V4_LOTS/CORE2_BATCH_05/",
  "blueprint_ref": "PHYS-QRT-BLUEPRINT",
  "adapter_ref": "PHYS-TOPIC-WPE",
  "permitted_outputs": ["bank/*.json", "rendered/*.html", "assets/*.svg", "test_*.py", "verify_*.js"],
  "forbidden_actions": ["git push", "git commit", "remote pr", "publish to public pages", "academic approval assertion"],
  "halt_conditions": ["BASELINE_DRIFT", "UNKNOWN_SOURCE_ID", "MISSING_FIGURE_SOURCE"]
}
```

---

## 3. Transfer Protocol 2: Builder → Reviewer (Delivery Handoff)

* **Direction:** Builder / Coder Agent $\to$ Local Reviewer Agent.
* **Payload Package:**
  1. `CODER_DELIVERY_TRANSACTION.json`
  2. Sealed Candidate Archive (`CORE2_BATCH_XX_PRIVATE_REVIEW.zip`)
  3. Standard Six-Line Agent Report in chat transcript.
* **Reviewer Invariant:** The reviewer rejects any delivery that does not include the six-line report and verifiable custody hashes.

### A. The Required Six-Line Delivery Report
```text
PAGE: file:///D:/CodeD/grade9v4/workspace/output/<ORDER>/rendered/core2_batchXX.html
CHANGES: [3–5 visible, checkable changes, e.g. "Rebuilt MathML", "Bound dynamic crux M2", "Fixed SVG height 100%"]
PROOF: [Actual shell commands, exit code 0, unit test pass count, Playwright 0px overflow result]
OPEN: [Top 1–5 HOLD/FAIL codes, e.g. "HOLD:ACADEMIC_ADMISSION"]
PUBLIC: NO_PUBLIC_CHANGE
PRIVATE: [Local ZIP path, byte count, SHA-256 digest]
```

### B. Schema Format (`CODER_DELIVERY_TRANSACTION.json`)
```json
{
  "contract": "grade9v4-coder-delivery-tx-v1",
  "transaction_id": "TX-DELIVERY-B05-20261102T133000Z",
  "order_id": "LOT-14-CORE2-B05-001",
  "sender": { "role": "BUILDER_CODER", "agent_id": "local-coder-agent" },
  "recipient": { "role": "LOCAL_QA_REVIEWER", "agent_id": "cc824cab-b1e0-4c4d-bdbe-88643078929e" },
  "batch_id": "BATCH-05",
  "total_questions": 10,
  "source_custody_claims": [
    { "sequence": 61, "source_id": "NSEP-2024-Q12", "stem_sha256": "4a71b28d..." }
  ],
  "self_check_attestation": {
    "unit_test_exit_code": 0,
    "playwright_exit_code": 0,
    "zero_overflow_mobile_375": true,
    "zero_overflow_desktop_1365": true,
    "zero_console_errors": true,
    "derivation_inert_before_commitment": true
  },
  "archive_path": "workspace/output/G9V4_LOTS/CORE2_BATCH_05/CORE2_BATCH_05_PRIVATE_REVIEW.zip",
  "archive_bytes": 41194,
  "archive_sha256": "124d84dba4b583facea7d4f1...",
  "governance_status": "HOLD:ACADEMIC_ADMISSION"
}
```

---

## 4. Transfer Protocol 3: Reviewer → Builder (Repair / Remediation Return)

* **Direction:** Local Reviewer Agent $\to$ Builder / Coder Agent.
* **Trigger:** Reviewer's independent audit detects any failure across the 4 Gates (Gate 0–3) or 7 Anti-Patterns.
* **Payload File:** `LOCAL_EXECUTION_RETURNED.json` (saved in `<ORDER>/LOCAL_EXECUTION_RETURNED.json`).
* **Coder Obligation:** The coder must ingest `LOCAL_EXECUTION_RETURNED.json`, execute bounded repairs, re-run local tests, and issue a fresh `Protocol 2` handoff. The coder must NOT dispute findings without cryptographic counter-evidence.

### Schema Format (`LOCAL_EXECUTION_RETURNED.json`)
```json
{
  "contract": "grade9v4-reviewer-return-tx-v1",
  "transaction_id": "TX-RETURN-B05-001",
  "order_id": "LOT-14-CORE2-B05-001",
  "reviewer_identity": "cc824cab-b1e0-4c4d-bdbe-88643078929e",
  "disposition": "RETURN_TO_BUILDER_FOR_REPAIR",
  "audit_timestamp_utc": "2026-11-02T13:45:00Z",
  "findings_count": 2,
  "findings": [
    {
      "code": "ERR_SVG_DIMENSION_INVALID",
      "severity": "FAIL",
      "file": "assets/fig_q61_raindrop_drag.svg",
      "details": "Root <svg> specified height='auto' which causes Chromium XML parsing warning.",
      "remediation_required": "Replace height='auto' with width='100%' height='100%' and control aspect ratio via CSS."
    },
    {
      "code": "ERR_CASCADE_ORDER_INTERCEPT",
      "severity": "FAIL",
      "file": "rendered/core2_batch05.html",
      "details": "Base .drawer-card declared after @media query causing mobile touch event interception.",
      "remediation_required": "Place base desktop styles before @media (max-width: 900px) block."
    }
  ],
  "bounded_repair_targets": [
    "assets/fig_q61_raindrop_drag.svg",
    "rendered/core2_batch05.html"
  ],
  "recheck_instruction": "Run node verify_batch05_playwright.js and assert consoleErrors.length === 0."
}
```

---

## 5. Transfer Protocol 4: Reviewer → Oracle / B2 / Owner (Escalation & Receipt)

* **Direction:** Local Reviewer Agent $\to$ Oracle / B2 Witness / Repository Owner.
* **Outcomes:**
  1. **Success Pathway (Technically Qualified):** Reviewer issues `BATCH_ARCHIVE_RECEIPT.json` registering the verified archive SHA-256 and byte size under `HOLD:ACADEMIC_ADMISSION`.
  2. **Gap Escalation Pathway (Unresolvable Ambiguity):** Reviewer issues `GAP_NOTE.json` when the problem turns on an undefined cognitive slot or missing topic blueprint adapter rule.

### A. Success Pathway (`BATCH_ARCHIVE_RECEIPT.json`)
```json
{
  "schema_version": "grade9v4-batch-receipt-v1",
  "batch_id": "BATCH-05",
  "archive_filename": "CORE2_BATCH_05_PRIVATE_REVIEW.zip",
  "archive_bytes": 41194,
  "archive_sha256": "124d84dba4b583facea7d4f1...",
  "timestamp_utc": "2026-11-02T13:50:00Z",
  "academic_admission": "NOT_ADMITTED",
  "disposition": "HOLD:ACADEMIC_ADMISSION",
  "total_questions": 10,
  "manifest_file_count": 16,
  "reviewer_identity": "cc824cab-b1e0-4c4d-bdbe-88643078929e",
  "governance_notice": "No academic approval inferred from software validation. Green CI means automatic tests passed; it never means student release is authorized."
}
```

### B. Gap Escalation Pathway (`GAP_NOTE.json`)
```json
{
  "gap_id": "GAP-WPE-D3.4-MODEL-001",
  "date": "2026-11-02",
  "reviewer": "LOCAL_QA_REVIEWER",
  "tile_id": "PHY-WPE-D3.4",
  "candidate_id": "EX-M62",
  "could_not_build": "D3.4 WPE variable-mass transfer instance absent in topic adapter",
  "missing_slot_or_rule": "Momentum impulse boundary conditions under relativistic limit",
  "oracle_decision": "PENDING"
}
```

---

## 6. Mechanical Pre-Flight Verification (`verify_handoff_transaction.py`)

The reviewer executes `python scripts/verify_handoff_transaction.py <path_to_tx_json>` prior to reviewing code. If pre-flight fails, the packet is rejected immediately without executing browser audits.
