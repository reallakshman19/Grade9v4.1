---
name: ag-core2
description: >-
  Standard operating procedure, architectural standard, and automated runbook for
  authoring, auditing, remediating, and packaging Grade9 Core 2 Source Question Learning Modules:
  Bounded Transfer Protocols (Work Order -> Delivery -> Repair Return -> Evidence Receipt),
  4-Gate Zero-Escape Foolproof Checklist, QRT 7-Operation Cognitive Demand, 5-Factor Rubric Bounds [0..2],
  Dynamic Crux Binding, Commitment-First Inert Derivations, W3C SVG Typography (>=14px), and Dual-Engine
  Verification (Python Unit Tests + Headless Playwright Viewport Audits).
---

# AG_Core2: Grade9 Core 2 Source Question Engineering Runbook

## Overview & Purpose

The **`ag-core2`** skill defines the canonical lifecycle, schemas, validation gates, and compilation procedures for transforming raw competitive exam items (e.g. JEE Main, NSEP, IPhO, Foundation) into interactive, tablet-ready **Core 2 Source Question Learning Modules**.

This skill operationalizes the **Physics QRT Blueprint (`PHYS-QRT-BLUEPRINT`)**, enforces the **Commitment-First Pedagogical Contract**, permanently prevents the **7 Critical Anti-Patterns**, and governs the **4 Bounded Transfer Protocols** between the Oracle, Builder, and Reviewer.

> [!IMPORTANT]
> **Universal Governance Invariant (Rule 13 in `AGENTS.md`)**:
> *"No academic approval inferred from software validation. Green CI means automatic tests passed; it never means student release is authorized."*
> All authored questions must default to `HOLD:ACADEMIC_ADMISSION` / `NOT_ADMITTED`. Software audits certify only syntactic, structural, and layout conformance.

---

## 1. The 7 Critical Anti-Patterns & Enforced Rules

Every Core 2 authoring and review session must strictly enforce compliance against these 7 failure modes (detailed in [`references/CRITICAL_ANTIPATTERNS.md`](references/CRITICAL_ANTIPATTERNS.md)):

| # | Anti-Pattern | Enforced Rule | Remediation Mechanism |
|---|---|---|---|
| **1** | **Lexical Ghost Text** (`"2. Connection:"`) | Section headers must strictly follow: `1. System Representation & Setup:`, `2. Physical Model & Formulation:`, `3. Execution & Resolution:`. | Zero tolerance for `"Connection"` in reasoning lists or DOM text. |
| **2** | **Static Crux Hardcoding** (`crux_move_ref = "M2"`) | Crux move must be **dynamically bound** based on primary cognitive demand. | `M1` for `RETRIEVE` / `REPRESENT`; `M2` for `MODEL` / `SYNTHESIZE` / `APPLY`; `M3` for `JUSTIFY`. Registered in `protected_move_refs`. |
| **3** | **Rubric Sum Drift** ($\sum c_i \neq \text{score}$) | Each of the 5 QRT complexity dimensions must be scored strictly in $\{0, 1, 2\}$, and their sum must exactly equal `difficulty.score`. | Strict unit test assertions: $c_i \in \{0, 1, 2\}$, $\sum c_i = \text{score}$, mapping to D1 (0–2), D2 (3–5), D3 (6–7), D4 (8–10). Never dilute to $\le 4$. |
| **4** | **Non-Canonical Verbs** (`CONNECT`, `CALCULATE`, `SOLVE`) | All primary operations, reasoning move kinds, and scaffold support types must belong strictly to the 7 canonical verbs. | $V_{\text{canonical}} = \{\text{RETRIEVE}, \text{EXPLAIN}, \text{APPLY}, \text{MODEL}, \text{REPRESENT}, \text{SYNTHESIZE}, \text{JUSTIFY}\}$. |
| **5** | **Invalid SVG Root Dimensions** (`height="auto"`) | Root `<svg>` tag must specify explicit length/percentages: `width="100%" height="100%"` with a responsive `viewBox`. Aspect ratio is managed via CSS. | Prevents Chromium SVG parser warnings in headless browser audits. Font sizes inside SVG must be $\ge 14\text{px}$. |
| **6** | **Mobile Viewport CSS Cascade Order** | Base desktop layout styles must precede `@media` queries; on mobile, sticky containers must reset to `position: static;`. | Guarantees 0px horizontal scroll overflow on 375px mobile viewports and prevents touch interception. |
| **7** | **Formative Derivation Leaks** | Derivations must remain strictly inert (`display: none;`) in the DOM until the learner commits an answer. | Dual event handlers unlock derivations only upon user commitment (MCQ selection or numerical input). |
| **8** | **Adversarial Jargon Leaks** | Student UI must never show developer mocks (`differs from producer proposal`, `asserted stem digest agrees with display`). | Student badges: `{Reviewed}`, `✅ CORRECT`, `❌ INCORRECT`. Technical hashes strictly encapsulated in `<details>`. |
| **9** | **SVG Named Entity XML Crashes** | Never use HTML named entities (`&middot;`, `&rarr;`, `&cross;`) inside SVG tags. | Strictly enforce literal UTF-8 (`·`, `→`, `✕`) or numeric character entities (`&#183;`, `&#8594;`). |
| **10**| **Missing Evaluation & Reset Loop** | An attempt commitment must yield an immediate visual feedback banner, colored badges, and an interactive reset control. | Implement `renderAttemptFeedback` banner + `[🔄 Reset & Try Again]` control restoring interactive state. |
| **11**| **Stale Browser Cache Serving** | Preview and production assets must never run stale cached scripts or data. | Mandatory cache-busting `?v=4.1.x` on `<script>` tags and `{ cache: "no-store" }` on dynamic JSON fetches. |
| **12**| **Dead Anchors & Hidden Workspaces** | Never leave dummy `href="#topic-view"` buttons or unhandled `#topicWorkspace` anchors. | Hash navigation and buttons must unhide the target workspace, select default topic, and smoothly scroll. |
| **13**| **Escaped Quote Attribute Syntax Traps** | Never use backslash-escaped quotes (`onclick="select(\'...\')"`) inside HTML attributes. | Use clean unescaped single quotes inside double quotes (`onclick="select('...')"`). |
| **14**| **Unrendered `source_figures` in Reader DOM** | Declaring `source_figures` in JSON without frontend rendering code leaves diagrams invisible. | Reader must check `q.source_figures`, render responsive `<img>` with `onerror` directory fallback. |
| **15**| **Single-Directory SVG Isolation (404)** | Placing SVGs in only one directory breaks pages at different subfolder depths. | Dual-tree SVG synchronization: all SVGs must exist in both `nsejs/assets/` and `nsejs/<subject>/assets/`. |
| **16**| **Stale Search Index Manifest Disconnect** | Adding questions or topics without recompiling search index breaks discovery and fails SHA pins. | Mandatory execution of `tools/build_search_index.py` and SHA-256 manifest sealing after bank updates. |

---

## 2. Core 2 Blueprint Cognitive Slot Architecture ($X, Y, Z, W$)

Every question derivation is structured into 4 standardized cognitive slots:

1. **Slot $X$ (Given Constraints & System Boundary):**
   - Declared in **Move 1** (`REPRESENT` or `RETRIEVE`).
   - Must state the explicit physical system boundary (e.g. `[body + incline + Earth]`) and reference datum (e.g. $U_{\text{grav}} = 0$ at incline base).
2. **Slot $Y$ (Demonstrated Anchor / Law):**
   - The governing physical principle (e.g. Work-Energy Theorem, Newton's 2nd Law, Conservation of Mechanical Energy).
3. **Slot $Z$ (Dependent Route / Formulation):**
   - Declared in **Move 2** (`MODEL` or `SYNTHESIZE`).
   - Sets up the integral, dynamic balance, or multi-stage state transition.
4. **Slot $W$ (The Protected Crux Move):**
   - The decisive cognitive pivot (e.g. algebraic root extraction, completing the square, vector dot product, or warrant).
   - Must be listed in `extensions.grade9v3:core2_support_plan.protected_move_refs`.
   - **Pre-Attempt Scaffolds (H1–H3) must NEVER reveal $W$.**

---

## 3. The 3-Tier Progressive Hint Scaffold (H1, H2, H3)

Every Core 2 question must include exactly 3 progressive pre-attempt hint tiers:

- **Tier 1 — H1 (`CLARIFY` / `REPRESENTATION`):** Clarifies what the question turns on, coordinate axes, and declared datums.
- **Tier 2 — H2 (`CORRELATE` / `FORMULATION`):** Links the crux to a demonstrated law ($Y$) without performing the execution.
- **Tier 3 — H3 (`OPEN_THE_WAY` / `RESOLUTION`):** Opens the algebraic/conceptual route ($Z$) without executing the protected crux move ($W$).
- **The "Never" Invariant:** No hint may reveal the answer, state the final numerical value, or eliminate MCQ options.

---

## 4. UI / Tablet Blueprint Standards

1. **Commitment-First Interactive Controls:**
   - **MCQ Questions:** Radio buttons with WCAG 2.5.5 touch target height $\ge 44\text{px}$ ($\ge 48\text{px}$ recommended for 12.7" tablets). Selecting an option enables the commit button.
   - **Numerical Questions:** Responsive `.num-input-group` with `flex-wrap: wrap;` and `box-sizing: border-box;` (max-width $220\text{px}$ on desktop, $100\%$ on mobile). Entering text enables the commit button.
   - Clicking **Commit** disables the inputs, freezes the choice, and animates `.derivation-section` to `display: block;`.
2. **Attempt Evaluation & Reset State Machine:**
   - **Feedback Banner:** Upon commitment, render `.attempt-feedback-banner` with immediate visual status:
     - `✅ CORRECT`: Confirms choice matches official verified key.
     - `❌ INCORRECT`: Explicitly names the student's selected choice, identifies the official correct key, and prompts review of the step-by-step derivation.
     - `ℹ️ DROPPED`: Identifies questions officially dropped by examination authorities.
   - **Visual Option Badging:**
     - User's correct selection: `.opt-user-correct` (emerald border & background, `✓ Correct (Your Choice)` badge).
     - User's incorrect selection: `.opt-user-wrong` (ruby border & background, `✗ Your Choice (Incorrect)` badge).
     - Official verified key: `.opt-correct-key` (emerald border, `✓ Correct Option` badge).
   - **Interactive Reset Control:** Render `[🔄 Reset & Try Again]` control restoring inputs to active state, clearing selection, and re-hiding derivations.
3. **Adversarial Jargon Purge & Encapsulated Audit Drawer:**
   - **Student Surface:** Zero developer mock phrases (`producer proposal`, `differs from producer proposal`, `asserted stem digest agrees with display`). Clean badges only: `{Reviewed} · B1–B7 peer review verified · Rule 13 HOLD` and `📅 Official Exam: [Year] · Set [Code] · Q[No]`.
   - **Audit Surface:** Technical SHA-256 hashes, QRT factor math, and integrity status must be encapsulated inside a collapsed `<details>` drawer:
     ```html
     <details class="q-source-custody-drawer">
       <summary>Data integrity &amp; QRT verification (technical audit; not admission)</summary>
       <div class="custody-hash-dump">
         <code>Stem SHA-256: [hash]</code>
       </div>
     </details>
     ```
4. **Client-Side Cache Invalidation Standards:**
   - Script tags in HTML must carry explicit version query parameters: `<script src=".../core2-physics-reader.js?v=4.1.5"></script>`.
   - All dynamic client-side `fetch()` requests for JSON candidate data must pass `{ cache: "no-store" }`.
5. **W3C SVG XML Strictness Standards:**
   - Root attributes: `width="100%" height="100%"` with responsive `viewBox`.
   - Strict XML compliance: **Zero HTML named entities** (`&middot;`, `&rarr;`, `&cross;`). Strictly use literal UTF-8 (`·`, `→`, `✕`) or numeric entities (`&#183;`).
   - SVG typography font-size $\ge 14\text{px}$ across all technical labels and dimensions.
6. **MathML Math Formatting:**
   - Mathematical expressions, fractions ($\frac{A}{B}$), powers ($10^7$), and units must render via semantic native `<math class="math-tex">` tags without external CDNs.
7. **Responsive Mobile Isolation:**
   - Container padding $\le 12\text{px}$ on mobile screens ($\le 600\text{px}$).
   - Zero horizontal scroll overflow across both Mobile (375x812) and Desktop (1365x900) viewports.
   - Instantaneous scroll navigation via `scrollIntoView({ behavior: 'auto' })` (never `'smooth'`).

---

## 5. The 4 Pillars of Core 2 Engineering Quality

To achieve true Olympiad-grade Core 2 quality and eliminate recurring audit regressions, every engineering session must satisfy the four non-negotiable operational pillars:

### Pillar 1: Procedure (Linear Execution Sequence)
Every Core 2 question or subject module must follow this deterministic 8-step build procedure:
1. **Intake & Gate 0 Custody**: Ingest question stems into `data/<subject>-core2-candidates.v1.json`, compute exact bit-for-bit SHA-256 (`stem_sha256`), and enforce unique IDs across all subject namespaces (0 collisions).
2. **QRT Slot Decomposition**: Deconstruct into Slots $X$ (boundary/datum), $Y$ (governing law), $Z$ (formulation), $W$ (crux pivot) using canonical 7 verbs, scored strictly in $[0..2]$ with $\sum c_i = \text{score}$.
3. **Scaffold Authoring**: Author exactly 3 progressive hints ($H_1, H_2, H_3$) protecting crux move $W$ (never revealing answer or numerical shortcuts).
4. **W3C Vector Graphic Dual-Sync**: Author SVG illustrations with responsive `viewBox`, `width="100%" height="100%"`, typography $\ge 14\text{px}$, and valid XML entities. Save synchronously to **both** `nsejs/assets/` and `nsejs/<subject>/assets/`.
5. **Reader DOM Binding**: Bind `q.source_figures` in frontend reader (`core2-<subject>-reader.js`), render `renderAttemptFeedback` banner + badges, wire `[🔄 Reset & Try Again]` control, and mount single master topic pill bar.
6. **Navigation & Anchor Hardening**: Replace dummy dead `#topic-view` anchors with active topic buttons; eliminate escaped quotes (`\'`) in HTML; ensure `#topicWorkspace` activates and auto-scrolls smoothly on hash navigation.
7. **Search Index Rebuild**: Execute `python tools/build_search_index.py` to regenerate the 346-document discovery index and update `learner-search-manifest.v1.json` with the new SHA-256 digest.
8. **Automated Verification**: Run `python tools/audit_nsejs_pages.py` (0 broken links across all 43 pages) and `pytest tests/test_<subject>_core2.py` (100% pass on Gate 0–3 invariants).

### Pillar 2: Workflow (Handoffs, States, Navigation & Routing)
- **The 3-State Attempt Evaluation Lifecycle**:
  - `State 1: Uncommitted`: Radio inputs enabled, derivations hidden (`display: none`), reset button hidden.
  - `State 2: Committed`: Inputs frozen, derivation revealed, `.attempt-feedback-banner` displayed (`✅ CORRECT` / `❌ INCORRECT`), option badges applied (`.opt-user-correct`, `.opt-user-wrong`, `.opt-correct-key`, `.opt-neutral-disabled`).
  - `State 3: Reset`: Clicking `[🔄 Reset & Try Again]` clears `localStorage`, restores active controls, hides derivations, and resets visual badges without page reload.
- **Topic Workspace State Machine**:
  - `Overview Grid (All Topics)` $\rightleftharpoons$ `Deep-Dive Workspace (Selected Topic)`.
  - Selecting a topic unhides `#topicWorkspace`, updates URL parameter (`?topic=...&q=...`) without page reload via `history.replaceState`, and smoothly scrolls (`scrollIntoView({ behavior: 'smooth', block: 'start' })`).
- **Disciplinary De-siloing**:
  - All questions organized strictly under the 6 Disciplinary Subject Topics, eradicating artificial "Recovery" pages and chronological exam-year silos.

### Pillar 3: Self-Check (Automated Pre-Flight Quality Linters)
Before handing off any delivery, the builder MUST run these 7 automated self-check assertions:
1. `audit_nsejs_pages.py`: Assert `Total broken links: 0` across all 43 repository pages.
2. `Dead Anchor Linter`: Search for `href="#topic-view"` or unhandled `#topicWorkspace` $\to$ must return 0 occurrences.
3. `HTML Quote Linter`: `Select-String -Path "nsejs\**\*.html" -Pattern "\\'"` $\to$ must return 0 occurrences.
4. `SVG Dual-Placement Check`: Every SVG in `nsejs/assets/` must also exist in `nsejs/<subject>/assets/`.
5. `Figure DOM Rendering Check`: Every question declaring `source_figures` must render an `<img>` in the reader DOM with an `onerror` secondary fallback.
6. `Stem Digest Parity`: `python -c "assert declared_matches_observed"` (0 hash mismatches).
7. `Adversarial String Linter`: 0 matches for `/producer-proposed/i` or `/differs from producer/i`.

### Pillar 4: Evidences (Concrete Tamper-Proof Deliverables)
Every delivery transaction must furnish these 5 concrete verification evidences:
1. **Link Audit Output**: Verbatim stdout of `audit_nsejs_pages.py` showing 43/43 pages pass.
2. **Subject Pytest Output**: Verbatim stdout of `py -3.14 -m pytest tests/test_<subject>_core2.py` showing 8/8 (or 9/9) tests pass.
3. **Inline Filter Pytest Output**: Verbatim stdout of `tests/test_qb_inline_filter.py` verifying evaluation styles, reset buttons, and quote syntax.
4. **Search Index Manifest Digest**: Exact SHA-256 digest in `learner-search-manifest.v1.json`.
5. **Visual State Proof Screenshots**: Browser viewport screenshots showing correct option green, incorrect option red, key highlight green, and feedback banner.

---

## 6. The Four Bounded Transfer Protocols

Work between agents is governed by strict bounded transfer protocols (see [`references/TRANSFER_PROTOCOLS.md`](references/TRANSFER_PROTOCOLS.md)):

```
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│                           THE FOUR TRANSFER PROTOCOLS                                   │
├──────────┬─────────────────────────────┬────────────────────────────────┬───────────────┤
│ Protocol │ Channel & Direction         │ Primary Artifact / Schema      │ Gate Action   │
├──────────┼─────────────────────────────┼────────────────────────────────┼───────────────┤
│ **TP 1** │ Oracle → Builder            │ `WORK_ORDER.json`              │ Dispatch      │
│ **TP 2** │ Builder → Reviewer          │ `CODER_DELIVERY_TRANSACTION`   │ Handoff       │
│ **TP 3** │ Reviewer → Builder          │ `LOCAL_EXECUTION_RETURNED`     │ Repair Return │
│ **TP 4** │ Reviewer → Oracle / B2      │ `BATCH_ARCHIVE_RECEIPT.json`   │ Evidence Lock │
└──────────┴─────────────────────────────┴────────────────────────────────┴───────────────┘
```

1. **TP 1: Work Order Dispatch (Oracle $\to$ Builder):** Read-only bounded scope (`G9V4_LOCAL_AGENT_WORK_ORDER_SCHEMA_v0.1.json`). Halts on baseline drift.
2. **TP 2: Delivery Handoff (Builder $\to$ Reviewer):** Requires sealed candidate ZIP, `CODER_DELIVERY_TRANSACTION.json`, and the standard 6-line delivery report. Verified via `python scripts/verify_handoff_transaction.py`.
3. **TP 3: Repair Return (Reviewer $\to$ Builder):** Dispatched upon any audit failure via `LOCAL_EXECUTION_RETURNED.json` specifying exact error codes and bounded repair targets.
4. **TP 4: Escalation & Receipt (Reviewer $\to$ Oracle / B2):** Issues detached cryptographic receipt under `HOLD:ACADEMIC_ADMISSION` or `GAP_NOTE.json` if blueprint ambiguity is discovered.

---

## 7. The 4-Gate Zero-Escape Foolproof Checklist

Every delivery must pass through all 4 sequential gates without bypass:

```
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│                       THE 4-GATE ZERO-ESCAPE CHECKLIST                                  │
├─────────────────────────────────────────────────────────────────────────────────────────┤
│ GATE 0: INTAKE & SOURCE CUSTODY                                                         │
│ [ ] Bit-for-bit stem SHA-256 match against source audit record (0-character drift).     │
│ [ ] Global repository-wide ID uniqueness (0 collisions across all subjects & years).    │
│ [ ] Sequential ordering (1..N contiguous) without missing or duplicate IDs.             │
│ [ ] Explicit question type declared (MCQ with options >= 2, or Numerical with []).      │
├─────────────────────────────────────────────────────────────────────────────────────────┤
│ GATE 1: QRT BLUEPRINT & COGNITIVE DEMAND                                                │
│ [ ] Exactly 0 occurrences of ghost text ("Connection:").                                │
│ [ ] Strict canonical 7-verb membership (RETRIEVE, EXPLAIN, APPLY, MODEL, etc.).        │
│ [ ] 5-Factor complexity rubric: each c_i in {0, 1, 2} and sum(c_i) == difficulty.score.│
│ [ ] Dynamic crux move binding (M1: Repr/Retr, M2: Model/Synth/Apply, M3: Justify).      │
│ [ ] Move 1 explicitly declares system boundary [body + incline + Earth] & datum U = 0.  │
├─────────────────────────────────────────────────────────────────────────────────────────┤
│ GATE 2: FRONTEND, TYPOGRAPHY & DOM STANDARDS                                            │
│ [ ] Pre-rendered static MathML typography (<math class="math-tex">); 0 external CDNs.   │
│ [ ] W3C compliant SVG root attributes (width="100%" height="100%"); never height="auto".│
│ [ ] Strict XML entity compliance in SVGs (0 HTML named entities like &middot; or &rarr;).│
│ [ ] SVG typography font-size >= 14px on all technical labels and dimensions.            │
│ [ ] Dual-directory SVG placement: SVGs exist in both nsejs/assets/ and subject assets.  │
│ [ ] Figure DOM rendering: every declared source_figures item renders in reader DOM.     │
│ [ ] In-page link integrity: 0 dead anchors (href="#topic-view" / #topicWorkspace).       │
│ [ ] Clean HTML attribute quotes: 0 backslash-escaped quotes (r"\'") inside attributes.   │
│ [ ] 0 occurrences of developer/mock jargon ("producer proposal", raw hash digests).    │
│ [ ] Technical hashes encapsulated inside collapsed <details class="q-source-custody">.  │
│ [ ] Attempt feedback banner (.attempt-feedback-banner) renders CORRECT / INCORRECT.     │
│ [ ] Interactive [🔄 Reset & Try Again] control present and functional.                  │
│ [ ] CSS cascade order: Desktop styles declared BEFORE @media (max-width: 900px).        │
│ [ ] Smooth scroll navigation on topic selection (scrollIntoView smooth).                │
│ [ ] Touch target height >= 44px on all pills, option buttons, and accordion headers.    │
│ [ ] Derivations remain display: none until explicit commitment (MCQ click / Num input). │
├─────────────────────────────────────────────────────────────────────────────────────────┤
│ GATE 3: DUAL VERIFICATION, SEALING & DETACHED RECEIPT                                   │
│ [ ] Dedicated subject pytest suite (test_<subject>_core2.py) passes with exit code 0.   │
│ [ ] Inline filter test suite (test_qb_inline_filter.py) passes with exit code 0.        │
│ [ ] Static link crawler audit (tools/audit_nsejs_pages.py) passes with 0 broken links.   │
│ [ ] Search index rebuilt (tools/build_search_index.py) with SHA-256 manifest sealed.    │
│ [ ] Playwright audit passes with 0 console errors, 0 network errors, and 0px overflow.  │
│ [ ] Playwright forbidden string check passes (0 regex matches for /producer/i).         │
│ [ ] Visual evidence screenshot captured: playwright_evidence_*.png.                     │
│ [ ] Sealed ZIP created with MANIFEST.json recording all payload SHA-256 hashes.         │
│ [ ] Detached receipt records archive SHA-256 and disposition HOLD:ACADEMIC_ADMISSION.   │
└─────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## 8. Dual Automated Verification Gate

Every batch or standalone compilation must pass two mandatory automated test suites:

### 1. Python Unit Test Suite (`test_batchXX.py`)
Must verify:
- `test_01`: Manifest integrity, batch ID, question counts, global ID uniqueness, and `HOLD:ACADEMIC_ADMISSION`.
- `test_02`: Verbatim stem SHA-256 invariance (0-character drift against source audit records).
- `test_03`: Canonical 7-verb membership for all primary ops, moves, and scaffolds; 5-factor rubric bounds in $\{0, 1, 2\}$ with $\sum c_i = \text{score}$.
- `test_04`: Declared system boundaries and $U=0$ datums.
- `test_05`: 3 hint tiers and protected crux move registration.
- `test_06`: SVG asset existence, typography $\ge 14\text{px}$, and zero HTML named entities in XML.
- `test_07`: Inert HTML template privacy (derivations hidden by default, zero external CDN links).
- `test_08`: Adversarial negative mutation tests (tampered stems, forbidden verbs, and fake approvals fail closed).

### 2. Headless Playwright Audit (`verify_batchXX_playwright.js`)
Must verify:
- **Viewport width check:** Mobile (375x812) and Desktop (1365x900) with exact **0px horizontal scroll overflow**.
- **Touch target check:** All interactive elements $\ge 44\text{px}$ height ($\ge 48\text{px}$ on tablets).
- **MathML element count:** $> 0$.
- **Forbidden string linter:** `0` regex matches for `/producer-proposed/i`, `/differs from producer/i`, `/asserted stem digest agrees/i`.
- **Interactive Lifecycle check:**
  1. Derivation hidden prior to commitment.
  2. Select option $\to$ Click commit $\to$ Derivation exposed.
  3. Attempt feedback banner (`✅ CORRECT` / `❌ INCORRECT`) rendered.
  4. Option badges applied (`.opt-user-correct`, `.opt-user-wrong`, `.opt-correct-key`).
  5. Click `[🔄 Reset & Try Again]` $\to$ Options re-enabled, banner cleared, derivation hidden.
- **Visual evidence artifact:** Capture timestamped PNG screenshot `playwright_evidence_qXX_[width].png`.
- **Zero console errors** (including SVG XML parsing errors) and zero HTTP 4xx/5xx network errors.

---

## 9. Packaging & Cryptographic Sealing Procedure

Once tests pass, package the review artifacts using the standard sealing protocol:
1. Capture `BATCH_TEST.log` and `BATCH_PLAYWRIGHT_TEST.log`.
2. Capture visual evidence screenshots `playwright_evidence_*.png`.
3. Compile `MANIFEST.json` containing individual payload file sizes and SHA-256 hashes.
4. Compress payload files into a sealed ZIP archive: `CORE2_BATCH_XX_PRIVATE_REVIEW.zip`.
5. Author a detached cryptographic receipt: `BATCH_XX_ARCHIVE_RECEIPT.json` capturing the archive byte size and SHA-256 digest.
6. Verify local mirror server returns HTTP 200 on all endpoints with proper cache invalidation.
